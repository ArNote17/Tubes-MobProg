package com.example.t1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity


class Onboarding3Activity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ob3)

        val nextButton = findViewById<ImageButton>(R.id.next2)
        nextButton.setOnClickListener {
            val intent = Intent(this, Onboarding4Activity::class.java)
            startActivity(intent)
        }
    }
}
