package com.example.t1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.auth.ktx.userProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class SignUp : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase Auth
        auth = Firebase.auth

        setContentView(R.layout.activity_signup)

        val btnBack: ImageButton = findViewById(R.id.btn_back)
        val putName: EditText = findViewById(R.id.input_nama)
        val putEmail: EditText = findViewById(R.id.input_email)
        val putPass: EditText = findViewById(R.id.input_password)
        val putPassC: EditText = findViewById(R.id.input_confirm_password)

        val btnSignup: Button = findViewById(R.id.btn_sign_up)
        val txtSignIn: TextView = findViewById(R.id.txt_sign_in)

        btnBack.setOnClickListener {
            val intent = Intent(this, DashboardLogin::class.java)
            startActivity(intent)
            finish()
        }

        txtSignIn.setOnClickListener {
            val intent = Intent(this, SignIn::class.java)
            startActivity(intent)
            finish()
        }

        btnSignup.setOnClickListener {
            val name = putName.text.toString()
            val email = putEmail.text.toString()
            val password = putPass.text.toString()
            val confirmPassword = putPassC.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()) {
                if (password == confirmPassword) {
                    handleRegister(name, email, password)
                } else {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleRegister(name: String, email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Registration successful
                    val user = auth.currentUser
                    val profileUpdates = userProfileChangeRequest {
                        displayName = name
                    }

                    user?.updateProfile(profileUpdates)
                        ?.addOnCompleteListener { profileUpdateTask ->
                            if (profileUpdateTask.isSuccessful) {
                                // Profile update successful
                                saveUserToDatabase(name, email, password)
                                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
                                // Redirect to SignIn activity
                                val intent = Intent(this, SignIn::class.java)
                                startActivity(intent)
                                finish() // Close current activity
                            } else {
                                // Profile update failed
                                Toast.makeText(this, "Profile update failed: ${profileUpdateTask.exception?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                } else {
                    // Registration failed
                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveUserToDatabase(name: String, email: String, password: String) {
        val database = FirebaseDatabase.getInstance("https://mobprog-2adb6-default-rtdb.asia-southeast1.firebasedatabase.app/")
        val userRef = database.getReference("users").child(name).child("akun")


        val user = User(name, email, password)

        userRef.setValue(user).addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Toast.makeText(this, "Failed to save user data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    data class User(val name: String, val email: String, val password: String)

    public override fun onStart() {
        super.onStart()
        // Optional: Sign out any existing user to ensure a fresh start
        auth.signOut()
    }
}
