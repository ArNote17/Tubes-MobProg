package com.example.t1

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RunningProcess : AppCompatActivity() {

    private lateinit var timerTextView: TextView
    private lateinit var kcalTextView: TextView

    @SuppressLint("DefaultLocale")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_running_process)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        timerTextView = findViewById(R.id.timerTextView)
        kcalTextView = findViewById(R.id.kcalTextView)

        val timeElapsed = intent.getLongExtra("TIME_ELAPSED", 0)
        val seconds = (timeElapsed / 1000).toInt() % 60
        val minutes = (timeElapsed / 1000 / 60).toInt()
        val formattedTime = String.format("%d:%02d", minutes, seconds)
        timerTextView.text = formattedTime
        kcalTextView.text = formattedTime
    }
}