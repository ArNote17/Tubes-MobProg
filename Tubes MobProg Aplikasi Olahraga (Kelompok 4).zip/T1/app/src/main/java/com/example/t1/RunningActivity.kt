package com.example.t1

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RunningActivity : AppCompatActivity() {

    private lateinit var playButton: ImageButton
    private lateinit var pauseButton: ImageButton
    private lateinit var timerTextView: TextView

    private var isRunning = false
    private var timeElapsed: Long = 0
    private var startTime: Long = 0

    private lateinit var timerHandler: Handler
    private lateinit var timerRunnable: Runnable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_running)

        playButton = findViewById(R.id.playButton)
        pauseButton = findViewById(R.id.pauseButton)
        timerTextView = findViewById(R.id.timerTextView)

        timerHandler = Handler()
        timerRunnable = object : Runnable {
            override fun run() {
                if (isRunning) {
                    val millis = System.currentTimeMillis() - startTime + timeElapsed
                    val seconds = (millis / 1000).toInt() % 60
                    val minutes = (millis / 1000 / 60).toInt()
                    timerTextView.text = String.format("%d:%02d", minutes, seconds)
                    timerHandler.postDelayed(this, 500)
                }
            }
        }

        playButton.setOnClickListener {
            if (!isRunning) {
                startStopwatch()
                playButton.setImageResource(R.drawable.play)
            } else {
                navigateToNextPage()
            }
        }

        pauseButton.setOnClickListener {
            if (isRunning) {
                pauseStopwatch()
                playButton.setImageResource(R.drawable.end)
                if(!isRunning){
                    playButton.setOnClickListener {
                        navigateToNextPage()
                    }
                }
            } else {
                startStopwatch()
                playButton.setImageResource(R.drawable.play)
            }
        }
    }

    private fun startStopwatch() {
        startTime = System.currentTimeMillis()
        timerHandler.postDelayed(timerRunnable, 0)
        isRunning = true
    }

    private fun pauseStopwatch() {
        timeElapsed += System.currentTimeMillis() - startTime
        timerHandler.removeCallbacks(timerRunnable)
        isRunning = false
    }

    private fun navigateToNextPage() {
        val intent = Intent(this, RunningProcess::class.java)
        val elapsedMillis = if (isRunning) {
            timeElapsed + (System.currentTimeMillis() - startTime)
        } else {
            timeElapsed
        }
        intent.putExtra("TIME_ELAPSED", elapsedMillis)
        startActivity(intent)
    }
}
