package com.example.t1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity


class Onboarding4Activity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ob4)

        val nextButton = findViewById<ImageButton>(R.id.next3)
        nextButton.setOnClickListener {
            val intent = Intent(this, DashboardLogin::class.java)
            startActivity(intent)
        }
    }
}
