package com.example.t1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class DashboardMenu : AppCompatActivity() {

    private lateinit var genderGroup: RadioGroup
    private lateinit var radioMale: RadioButton
    private lateinit var radioFemale: RadioButton
    private lateinit var inputAge: EditText
    private lateinit var inputHeight: EditText
    private lateinit var inputWeight: EditText
    private lateinit var nextButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard_menu)

        genderGroup = findViewById(R.id.radioGroupGender)
        radioMale = findViewById(R.id.radioMale)
        radioFemale = findViewById(R.id.radioFemale)
        inputAge = findViewById(R.id.inputAge)
        inputHeight = findViewById(R.id.inputHeight)
        inputWeight = findViewById(R.id.inputWeight)
        nextButton = findViewById(R.id.next)

        nextButton.setOnClickListener {
            saveUserData()
        }
    }

    private fun saveUserData() {
        val gender = if (radioMale.isChecked) "Male" else "Female"
        val age = inputAge.text.toString()
        val height = inputHeight.text.toString()
        val weight = inputWeight.text.toString()

        if (age.isNotEmpty() && height.isNotEmpty() && weight.isNotEmpty()) {
            val username = intent.getStringExtra("username")
            val database = FirebaseDatabase.getInstance("https://mobprog-2adb6-default-rtdb.asia-southeast1.firebasedatabase.app/")
            val userRef = database.getReference("users").child(username!!).child("data")

            val userData = UserData(username, gender, age, height, weight)
            userRef.setValue(userData).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show()
                    // Redirect to next activity if necessary
                    val intent = Intent(this, ProfileActivity::class.java)
                    intent.putExtra("username", username)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Failed to save data: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
        }
    }

    data class UserData(val name: String, val gender: String, val age: String, val height: String, val weight: String)
}
