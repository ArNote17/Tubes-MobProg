package com.example.t1

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var profileName: TextView
    private lateinit var profileAge: TextView
    private lateinit var profileHeight: TextView
    private lateinit var profileWeight: TextView
    private lateinit var navAct: ImageButton
    private lateinit var navHome: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profileName = findViewById(R.id.profileName)
        profileAge = findViewById(R.id.profileAge)
        profileHeight = findViewById(R.id.profileHeight)
        profileWeight = findViewById(R.id.profileWeight)
        navAct = findViewById(R.id.btn_activity)
        navHome = findViewById(R.id.btn_home)

        navHome.setOnClickListener {
//            val intent = Intent(this, HomeActivity::class.java)
//            startActivity(intent)
        }

        navAct.setOnClickListener {
            val intent = Intent(this, PageActivity::class.java)
            startActivity(intent)
        }

        val username = intent.getStringExtra("username") ?: return

        database = FirebaseDatabase.getInstance("https://mobprog-2adb6-default-rtdb.asia-southeast1.firebasedatabase.app/")
            .getReference("users").child(username).child("data")

        loadData()
    }

    private fun loadData() {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userData = snapshot.getValue(UserData::class.java)
                if (userData != null) {
                    profileName.text = userData.name
                    profileAge.text = userData.age
                    profileHeight.text = userData.height
                    profileWeight.text = userData.weight
                } else {
                    Toast.makeText(this@ProfileActivity, "User data not found", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ProfileActivity, "Failed to load data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    data class UserData(val name: String = "", val age: String = "", val height: String = "", val weight: String = "")
}
