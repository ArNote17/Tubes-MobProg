package com.example.t1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class SignIn : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)

        // Initialize Firebase Auth and Database
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance("https://mobprog-2adb6-default-rtdb.asia-southeast1.firebasedatabase.app/").reference.child("users")

        val btnBack: ImageButton = findViewById(R.id.btn_back)
        val inputName: EditText = findViewById(R.id.input_nama)
        val inputEmail: EditText = findViewById(R.id.input_email)
        val inputPassword: EditText = findViewById(R.id.input_password)

        val btnSignIn: Button = findViewById(R.id.btn_sign_in)
        val txtSignUp: TextView = findViewById(R.id.txt_sign_up)

        btnBack.setOnClickListener {
            val intent = Intent(this, DashboardLogin::class.java)
            startActivity(intent)
            finish()
        }

        txtSignUp.setOnClickListener {
            val intent = Intent(this, SignUp::class.java)
            startActivity(intent)
            finish()
        }

        btnSignIn.setOnClickListener {
            val name = inputName.text.toString()
            val email = inputEmail.text.toString()
            val password = inputPassword.text.toString()

            if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                verifyUser(name, email, password)
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun verifyUser(name: String, email: String, password: String) {
        database.child(name).child("akun").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val user = snapshot.getValue(User::class.java)
                if (user?.email == email && user.password == password) {
                    Toast.makeText(this@SignIn, "Login successful", Toast.LENGTH_SHORT).show()
                    // Check if user data is complete
                    checkUserDataComplete(name)
                } else {
                    Toast.makeText(this@SignIn, "Invalid credentials", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@SignIn, "Database error", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun checkUserDataComplete(username: String) {
        database.child(username).child("data").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userData = snapshot.getValue(UserData::class.java)
                if (userData?.age != null && userData.gender != null && userData.height != null && userData.weight != null) {
                    // Data is complete, go to ProfileActivity
                    val intent = Intent(this@SignIn, ProfileActivity::class.java)
                    intent.putExtra("username", username)
                    startActivity(intent)
                    finish()
                } else {
                    // Data is incomplete, go to DashboardMenu
                    val intent = Intent(this@SignIn, DashboardMenu::class.java)
                    intent.putExtra("username", username)
                    startActivity(intent)
                    finish()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@SignIn, "Database error", Toast.LENGTH_SHORT).show()
            }
        })
    }

    data class User(val email: String = "", val password: String = "")
    data class UserData(val age: String? = null, val gender: String? = null, val height: String? = null, val weight: String? = null)
}
